print "BAZ"
