print "BAR"
