print "Foo"
